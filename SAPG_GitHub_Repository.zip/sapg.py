"""
SAPG: Stress-Aware Power Governor for electrically heated refractory linings.
Python mirror of sapg_main.m (same algorithm, same LCG random numbers).

State (deviation from ambient):  x = [theta_1 .. theta_N, theta_f]
  theta_1 = hot face, theta_N = cold face, theta_f = chamber (heater) temperature
Input u = electric heater power density [W/m^2 of lining]
"""
import numpy as np
from scipy.linalg import expm

# ------------------------------------------------------------------ parameters
P = dict(
    L=0.15, N=16, rho=2600.0, cp=1050.0,
    k_model=2.0,                 # conductivity used by estimator/governor [W/mK]
    k_true0=2.4, k_slope=2.0e-4, # plant: k(T) = k_true0*(1-k_slope*(T-25))*(1+dk)
    hi=300.0, ho=15.0, cf=3.0e4,
    he_heat=5.0, he_cool=25.0,   # chamber leakage (cooling fan off / on)
    Ta=25.0, Tset=1200.0, Tlow=40.0, Tend_hot=200.0,
    E=20e9, aT=6e-6, nu=0.2, St=6e6, Sc=60e6,
    umax=40e3, dt=120.0, H=90,
    phi_d=0.80,                  # design utilisation limit (fraction of strength)
    phi_g=0.70,                  # governor target (margin vs design limit)
    m_dmg=10.0,                  # damage exponent
    t_soak=3*3600.0, tmax=150*3600.0,
    sens_idx=(2, 8),             # thermocouple nodes (0-based): x = 0.02 m, 0.08 m
    sig_y=1.5, sig_w=0.2,        # measurement noise, process noise [K]
    q_l=0.6**2, q_f=1.0**2,      # KF process-noise variances
    kp=300.0, ti=600.0,          # PI on chamber temperature
)

# ------------------------------------------------------------------ rng (LCG, identical in MATLAB)
class LCG:
    def __init__(self, seed):
        self.s = int(seed) % 4294967296
    def u(self):
        self.s = (1664525 * self.s + 1013904223) % 4294967296
        return (self.s + 0.5) / 4294967296.0
    def n(self):
        u1 = self.u(); u2 = self.u()
        return np.sqrt(-2.0 * np.log(u1)) * np.cos(2 * np.pi * u2)

# ------------------------------------------------------------------ model
def build_AB(p, kif, hi, ho, cf, he, cvol):
    N = p['N']; dx = p['L'] / (N - 1); n = N + 1
    A = np.zeros((n, n)); B = np.zeros((n, 1))
    m = np.full(N, cvol * dx); m[0] = m[-1] = cvol * dx / 2
    for i in range(N - 1):
        g = kif[i] / dx
        A[i, i] -= g / m[i];     A[i, i + 1] += g / m[i]
        A[i + 1, i + 1] -= g / m[i + 1]; A[i + 1, i] += g / m[i + 1]
    A[0, 0] -= hi / m[0]; A[0, N] += hi / m[0]
    A[N - 1, N - 1] -= ho / m[N - 1]
    A[N, N] -= (hi + he) / cf; A[N, 0] += hi / cf
    B[N, 0] = 1.0 / cf
    return A, B

def discretise(A, B, dt):
    n = A.shape[0]
    M = np.zeros((n + 1, n + 1)); M[:n, :n] = A * dt; M[:n, n:] = B * dt
    Ex = expm(M)
    return Ex[:n, :n], Ex[:n, n:]

def stress_matrix(p):
    N = p['N']; L = p['L']; dx = L / (N - 1)
    xs = np.linspace(0, L, N)
    w = np.full(N, dx); w[0] = w[-1] = dx / 2
    W = np.diag(w)
    V = np.column_stack([np.ones(N), xs - L / 2])
    Pi = V @ np.linalg.solve(V.T @ W @ V, V.T @ W)
    beta = p['E'] * p['aT'] / (1 - p['nu'])
    S = -beta * (np.eye(N) - Pi)
    S = np.hstack([S, np.zeros((N, 1))])
    return S

def model_set(p):
    """Nominal discrete models for the two fan modes, KF gains, prediction stacks."""
    N = p['N']; n = N + 1; cvol = p['rho'] * p['cp']
    S = stress_matrix(p)
    Cc = np.vstack([S / p['St'], -S / p['Sc']])          # utilisation rows
    Hm = np.zeros((len(p['sens_idx']) + 1, n))
    for r, i in enumerate(p['sens_idx']): Hm[r, i] = 1.0
    Hm[-1, N] = 1.0
    R = np.diag([p['sig_y']**2] * Hm.shape[0])
    Q = np.diag([p['q_l']] * N + [p['q_f']])
    out = {}
    for mode, he in (('heat', p['he_heat']), ('cool', p['he_cool'])):
        kif = np.full(N - 1, p['k_model'])
        A, B = build_AB(p, kif, p['hi'], p['ho'], p['cf'], he, cvol)
        Ad, Bd = discretise(A, B, p['dt'])
        # steady-state Kalman gain by Riccati iteration
        Pc = np.eye(n) * 10.0
        for _ in range(4000):
            Pm = Ad @ Pc @ Ad.T + Q
            K = Pm @ Hm.T @ np.linalg.inv(Hm @ Pm @ Hm.T + R)
            Pn = (np.eye(n) - K @ Hm) @ Pm
            if np.max(np.abs(Pn - Pc)) < 1e-10: Pc = Pn; break
            Pc = Pn
        Pm = Ad @ Pc @ Ad.T + Q
        K = Pm @ Hm.T @ np.linalg.inv(Hm @ Pm @ Hm.T + R)
        # prediction stacks for held input over horizon H
        Mall = []; Gall = []
        Aj = np.eye(n); Gam = np.zeros((n, 1))
        for j in range(1, p['H'] + 1):
            Gam = Ad @ Gam + Bd          # sum_{i<j} Ad^i Bd
            Aj = Ad @ Aj
            Mall.append(Cc @ Aj); Gall.append(Cc @ Gam)
        out[mode] = dict(Ad=Ad, Bd=Bd, K=K, Mall=np.vstack(Mall),
                         Gall=np.vstack(Gall).ravel())
    return out, Cc, Hm, S

def plant_step(p, th, u, he, dk, dh, dcp, w):
    N = p['N']; cvol = p['rho'] * p['cp'] * (1 + dcp)
    T = th[:N] + p['Ta']
    Tif = 0.5 * (T[:-1] + T[1:])
    kif = p['k_true0'] * (1 - p['k_slope'] * (Tif - 25.0)) * (1 + dk)
    A, B = build_AB(p, kif, p['hi'] * (1 + dh), p['ho'] * (1 + 0.5 * dh), p['cf'], he, cvol)
    Ad, Bd = discretise(A, B, p['dt'])
    return Ad @ th + Bd[:, 0] * u + w

# ------------------------------------------------------------------ one thermal cycle
def run_cycle(p, models, Cc, Hm, strategy, ramp_h=None, ramp_c=None,
              dk=0.0, dh=0.0, dcp=0.0, seed=1, noise=True, use_kf=True, phi_g=None):
    N = p['N']; n = N + 1; dt = p['dt']
    rng = LCG(seed)
    th = np.zeros(n)                     # true state
    xh = np.zeros(n)                     # estimate
    phase = 'heat'; t_soak0 = None; t_cool0 = None
    integ = 0.0; nsteps = int(p['tmax'] / dt)
    rec = dict(t=[], Tf=[], T1=[], TN=[], u=[], phi=[], phi_hat=[])
    energy = 0.0; infeas = 0
    phi_heat = 0.0; phi_cool = 0.0
    t = 0.0
    for k in range(nsteps):
        mode = 'heat' if phase != 'cool' else 'cool'
        he = p['he_heat'] if mode == 'heat' else p['he_cool']
        mdl = models[mode]
        # --- measurement and estimate update
        yv = Hm @ th
        if noise:
            yv = yv + p['sig_y'] * np.array([rng.n() for _ in range(Hm.shape[0])])
        if k == 0:
            xh_pred = xh.copy()
        resid = yv - Hm @ xh_pred
        xh = xh_pred + mdl['K'] @ resid if use_kf else xh_pred.copy()
        Tf_meas = yv[-1] + p['Ta']
        # --- phase logic
        if phase == 'heat' and Tf_meas >= p['Tset'] - 3.0:
            phase = 'soak'; t_soak0 = t
        if phase == 'soak' and t - t_soak0 >= p['t_soak']:
            phase = 'cool'; t_cool0 = t; mode = 'cool'; mdl = models['cool']
            he = p['he_cool']
        # --- reference
        if strategy == 'ramp':
            if phase == 'heat':
                Tref = p['Ta'] + ramp_h * t / 3600.0
            elif phase == 'soak':
                Tref = p['Tset']
            else:
                Tref = max(p['Tset'] - ramp_c * (t - t_cool0) / 3600.0, p['Tlow'])
        else:
            Tref = p['Tset'] if phase != 'cool' else p['Tlow']
        # --- nominal PI
        e = Tref - Tf_meas
        u_nom = p['kp'] * e + p['kp'] / p['ti'] * integ
        u_cmd = min(max(u_nom, 0.0), p['umax'])
        # --- stress governor
        if strategy == 'sapg':
            pg = p['phi_g'] if phi_g is None else phi_g
            a = mdl['Mall'] @ xh; b = mdl['Gall']; rhs = pg - a
            pos = b > 1e-12; neg = b < -1e-12
            hi_ = p['umax']
            if pos.any(): hi_ = min(hi_, np.min(rhs[pos] / b[pos]))
            lo_ = 0.0
            if neg.any(): lo_ = max(lo_, np.max(rhs[neg] / b[neg]))
            hi_ = max(hi_, 0.0)
            if lo_ > hi_:
                infeas += 1; u_f = 0.5 * (lo_ + hi_)
            else:
                u_f = min(max(u_cmd, lo_), hi_)
            u = min(max(u_f, 0.0), p['umax'])
        else:
            u = u_cmd
        # anti-windup (clamping): integrate only when not modified
        if abs(u - u_nom) < 1e-9:
            integ += e * dt
        # --- record (true quantities)
        phi_true = float(np.max(Cc @ th))
        rec['t'].append(t); rec['Tf'].append(th[N] + p['Ta']); rec['T1'].append(th[0] + p['Ta'])
        rec['TN'].append(th[N - 1] + p['Ta']); rec['u'].append(u)
        rec['phi'].append(phi_true); rec['phi_hat'].append(float(np.max(Cc @ xh)))
        if phase in ('heat', 'soak'): phi_heat = max(phi_heat, phi_true)
        else: phi_cool = max(phi_cool, phi_true)
        energy += u * dt
        # --- end condition
        if phase == 'cool' and th[0] + p['Ta'] <= p['Tend_hot']:
            break
        # --- propagate
        w = np.zeros(n)
        if noise:
            w[:N] = p['sig_w'] * np.array([rng.n() for _ in range(N)])
        th = plant_step(p, th, u, he, dk, dh, dcp, w)
        xh_pred = mdl['Ad'] @ xh + mdl['Bd'][:, 0] * u
        t += dt
    for key in rec: rec[key] = np.array(rec[key])
    t_heat = t_soak0 if t_soak0 is not None else np.nan
    return dict(rec=rec, t_total=t, t_heat=t_heat, phi_heat=phi_heat, phi_cool=phi_cool,
                energy_kwh=energy / 3.6e6, infeas=infeas, finished=(phase == 'cool'))

def damage(p, res):
    return res['phi_heat'] ** p['m_dmg'] + res['phi_cool'] ** p['m_dmg']

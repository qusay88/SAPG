# SAPG — Stress-Aware Power Governor

This repository contains the MATLAB and Python implementations accompanying the paper:

**Stress-Aware Power Governor for Refractory Protection: A Kalman-Filtered Predictive Safety Filter for Electrically Heated Furnaces**

## Overview

SAPG is a safety layer placed between a nominal temperature controller and the electric heater of a refractory-lined furnace.

The implementation combines:

- A 1-D transient heat-conduction model of the refractory lining
- A lumped chamber-temperature state
- A steady-state Kalman filter using three thermocouple measurements
- Predictive thermal-stress utilization constraints
- A power governor that limits the nominal PI command when predicted refractory stress approaches the design limit
- Matched Monte Carlo simulations
- Cycle-level thermal-damage sensitivity analysis

The study is a **simulation/numerical proof-of-concept**. The results should not be interpreted as experimental validation, a safety certificate, or a validated refractory-life prediction.

## Files

| File | Description |
|---|---|
| `sapg_main.m` | MATLAB implementation of the SAPG simulation |
| `sapg.py` | Python implementation/mirror of the MATLAB algorithm |
| `README.md` | Repository documentation |

## MATLAB

The MATLAB implementation is designed to run with base MATLAB.

Open MATLAB, place `sapg_main.m` in the working directory, and run:

```matlab
sapg_main
```

The MATLAB source states that MATLAB R2020a or newer is required and that no additional toolboxes are required.

A 100-cycle Monte Carlo run may take approximately 10–20 minutes depending on the computer.

## Python

The Python implementation uses NumPy and SciPy.

Install the required packages:

```bash
pip install numpy scipy
```

Then run:

```bash
python sapg.py
```

The Python implementation is intended to mirror the MATLAB algorithm and uses the same 32-bit linear congruential generator so that the stochastic simulations are reproducible across the two implementations.

## Reproducibility

The model uses a common parameterization and matched random-number generation for the Monte Carlo experiments.

Important simulation features include:

- 16 refractory nodes plus one chamber state
- Three temperature measurements
- 120 s sampling interval
- Kalman filtering
- Predictive safety filtering
- Matched parameter perturbations across control strategies
- Cycle-level damage calculation

For publication-quality reproduction, use the exact parameter values and simulation settings reported in the associated manuscript.

## Important note on material parameters

The manuscript describes several material/model parameters as representative or illustrative rather than plant-calibrated. Therefore, the repository should not be interpreted as providing a calibrated model of a particular industrial furnace or refractory product.

## Citation

If you use this code, please cite the associated paper:

Q. H. Alsultan, O. J. alhayali, and S. Aljanabi,
“Stress-Aware Power Governor for Refractory Protection: A Kalman-Filtered Predictive Safety Filter for Electrically Heated Furnaces.”

## License

This repository does not currently assign a specific open-source license. Add a license file if you want to permit reuse under defined terms.

%% SAPG_MAIN  Stress-Aware Power Governor (SAPG) for electrically heated refractory linings
%
%  A Kalman-filtered, predictive thermal-stress safety filter placed between the
%  temperature controller and the heater (thyristor) of a refractory-lined furnace.
%
%  Plant     : 1-D heat conduction through the lining (N nodes) + lumped chamber.
%              Temperature-dependent conductivity, parametric mismatch, process noise.
%  Estimator : steady-state Kalman filter on a nominal LTI model, 3 thermocouples.
%  Governor  : one-step safety filter  u = clip(u_PI, lo, hi),  where [lo, hi] come from
%              linear constraints on the predicted stress utilisation over horizon H.
%  Damage    : Miner-type  D = phi_heat^m + phi_cool^m  per thermal cycle.
%
%  Requirements: base MATLAB only (R2020a or newer for boxchart). No toolboxes.
%  Random numbers: a 32-bit LCG is used so that results are reproducible and identical to
%  the Python mirror (sapg.py).
%
%  Run:  >> sapg_main        (about 10-20 minutes for NMC = 100)
%
%  Units: SI, power as W per m^2 of lining area, temperatures in degC, time in s.

clear; clc; close all;
NMC          = 100;      % Monte Carlo runs
RUN_PARETO   = false;    % set true to also sweep phi_g and ramp rates (slow)

p = params();
[mdl, Cc, Hm] = model_set(p);

%% 1) Offline design of the best static ramps (industry baseline) on the nominal plant
rp.rh_d = best_ramp(p, mdl, Cc, Hm, 'h', p.phi_d);
rp.rc_d = best_ramp(p, mdl, Cc, Hm, 'c', p.phi_d);
rp.rh_g = best_ramp(p, mdl, Cc, Hm, 'h', p.phi_g);
rp.rc_g = best_ramp(p, mdl, Cc, Hm, 'c', p.phi_g);
fprintf('Best static ramps [K/h]: heat %.1f / cool %.1f (phi_d), heat %.1f / cool %.1f (phi_g)\n', ...
        rp.rh_d, rp.rc_d, rp.rh_g, rp.rc_g);

%% 2) Monte Carlo under parametric uncertainty and sensor noise
names = {'free', 'ramp_d', 'ramp_g', 'sapg'};
opts  = {opt('free'), opt('ramp', rp.rh_d, rp.rc_d), opt('ramp', rp.rh_g, rp.rc_g), opt('sapg')};
lcg   = 2026;
res   = struct();
for j = 1:numel(names), res.(names{j}) = zeros(NMC, 8); end
draws = zeros(NMC, 3);
for i = 1:NMC
    [u1, lcg] = lcg_u(lcg); [u2, lcg] = lcg_u(lcg); [u3, lcg] = lcg_u(lcg);
    draws(i, :) = [0.2*(2*u1-1), 0.3*(2*u2-1), 0.1*(2*u3-1)];     % dk, dh, dcp
end
for i = 1:NMC
    for j = 1:numel(names)
        o = opts{j}; o.dk = draws(i,1); o.dh = draws(i,2); o.dcp = draws(i,3);
        o.seed = 1000 + i; o.noise = true;
        r = run_cycle(p, mdl, Cc, Hm, o);
        dmg = r.phi_heat^p.m_dmg + r.phi_cool^p.m_dmg;
        res.(names{j})(i, :) = [r.t_total/3600, r.t_soak0/3600, r.phi_heat, r.phi_cool, ...
                                r.energy_kwh, dmg, r.finished, r.infeas];
    end
    if mod(i, 10) == 0, fprintf('  MC %d / %d\n', i, NMC); end
end

fprintf('\n%-7s %8s %8s %8s %8s %9s %9s %9s\n', 'method', 'time[h]', 'phi_h', 'phi_c', 'P(>0.8)', 'P(>1)', 'damage', 'kWh/m2');
for j = 1:numel(names)
    a = res.(names{j}); pk = max(a(:,3), a(:,4));
    fprintf('%-7s %8.1f %8.2f %8.2f %8.0f%% %8.0f%% %9.3f %9.0f\n', names{j}, mean(a(:,1)), mean(a(:,3)), ...
            mean(a(:,4)), 100*mean(pk > 0.8), 100*mean(pk > 1.0), mean(a(:,6)), mean(a(:,5)));
end
save('sapg_results.mat', 'res', 'rp', 'draws', 'p');

%% 3) Figure A: time histories with conductivity 20 % below nominal
o1 = opt('ramp', rp.rh_d, rp.rc_d); o2 = opt('sapg');
o1.dk = -0.20; o1.seed = 7; o1.noise = true;
o2.dk = -0.20; o2.seed = 7; o2.noise = true;
rA = run_cycle(p, mdl, Cc, Hm, o1);
rB = run_cycle(p, mdl, Cc, Hm, o2);
blue = [42 120 214]/255; orange = [235 104 52]/255;
figure('Position', [100 100 700 650]);
subplot(3,1,1); hold on; grid on;
plot(rA.t/3600, rA.T1, '--', 'Color', orange, 'LineWidth', 1.6);
plot(rB.t/3600, rB.T1, '-',  'Color', blue,   'LineWidth', 1.6);
ylabel('Hot-face temperature (^\circC)'); legend('Static ramp (nominal-tuned)', 'SAPG (proposed)', 'Location', 'northwest');
subplot(3,1,2); hold on; grid on;
plot(rA.t/3600, rA.u/1e3, '--', 'Color', orange); plot(rB.t/3600, rB.u/1e3, '-', 'Color', blue);
ylabel('Heater power (kW/m^2)');
subplot(3,1,3); hold on; grid on;
plot(rA.t/3600, rA.phi, '--', 'Color', orange); plot(rB.t/3600, rB.phi, '-', 'Color', blue);
yline(p.phi_d, ':k', 'design limit \phi = 0.8'); yline(1.0, ':r', 'predicted spalling \phi = 1');
ylim([-0.05 1.25]); ylabel('Stress utilisation \phi'); xlabel('Time (h)');
exportgraphics(gcf, 'sapg_fig_timeseries.png', 'Resolution', 300);

%% 4) Figure B: Monte Carlo distributions
figure('Position', [100 100 700 330]);
lbl = {'Static ramp (\phi_d)', 'Static ramp (\phi_g)', 'SAPG'};
sel = {'ramp_d', 'ramp_g', 'sapg'};
subplot(1,2,1); hold on; grid on;
for j = 1:3, a = res.(sel{j}); boxchart(j*ones(NMC,1), max(a(:,3), a(:,4))); end
yline(0.8, ':k'); yline(1.0, ':r'); xticks(1:3); xticklabels(lbl); ylabel('Peak stress utilisation \phi');
subplot(1,2,2); hold on; grid on;
for j = 1:3, a = res.(sel{j}); boxchart(j*ones(NMC,1), a(:,1)); end
xticks(1:3); xticklabels(lbl); ylabel('Cycle time (h)');
exportgraphics(gcf, 'sapg_fig_montecarlo.png', 'Resolution', 300);

%% 5) Optional: Pareto sweep (cycle time vs damage) and estimator ablation
if RUN_PARETO
    NS = 40;
    pg_list = [0.55 0.60 0.65 0.70 0.75 0.80];
    sc_list = [0.5 0.6 0.7 0.8 0.9 1.0 1.1];
    par_s = zeros(numel(pg_list), 3); par_r = zeros(numel(sc_list), 3);
    for q = 1:numel(pg_list)
        o = opt('sapg'); o.phi_g = pg_list(q); par_s(q,:) = mc_mean(p, mdl, Cc, Hm, o, draws, NS);
    end
    for q = 1:numel(sc_list)
        o = opt('ramp', rp.rh_d*sc_list(q), rp.rc_d*sc_list(q)); par_r(q,:) = mc_mean(p, mdl, Cc, Hm, o, draws, NS);
    end
    o = opt('sapg'); o.use_kf = false; ab_ol = mc_mean(p, mdl, Cc, Hm, o, draws, NS);
    o = opt('sapg');                   ab_kf = mc_mean(p, mdl, Cc, Hm, o, draws, NS);
    fprintf('Ablation  [time, mean peak phi, damage]: KF %s | open-loop %s\n', mat2str(ab_kf, 3), mat2str(ab_ol, 3));
    figure; semilogy(par_s(:,1), par_s(:,3), '-o', 'Color', blue, 'LineWidth', 1.6); hold on; grid on;
    semilogy(par_r(:,1), par_r(:,3), '--s', 'Color', orange, 'LineWidth', 1.4);
    xlabel('Mean cycle time (h)'); ylabel('Mean damage per cycle'); legend('SAPG', 'Static ramp');
    exportgraphics(gcf, 'sapg_fig_pareto.png', 'Resolution', 300);
end

%% ======================================================================== local functions
function p = params()
p.L = 0.15; p.N = 16; p.rho = 2600; p.cp = 1050;
p.k_model = 2.0;                       % conductivity used by estimator / governor [W/mK]
p.k_true0 = 2.4; p.k_slope = 2.0e-4;   % plant: k(T) = k_true0*(1 - k_slope*(T-25))*(1+dk)
p.hi = 300; p.ho = 15; p.cf = 3.0e4;
p.he_heat = 5; p.he_cool = 25;         % chamber leakage / cooling fan [W/m2K]
p.Ta = 25; p.Tset = 1200; p.Tlow = 40; p.Tend_hot = 200;
p.E = 20e9; p.aT = 6e-6; p.nu = 0.2; p.St = 6e6; p.Sc = 60e6;
p.umax = 40e3; p.dt = 120; p.H = 90;
p.phi_d = 0.80;                        % design utilisation limit (fraction of strength)
p.phi_g = 0.70;                        % governor target (margin against model error)
p.m_dmg = 10;                          % damage exponent
p.t_soak = 3*3600; p.tmax = 150*3600;
p.sens_idx = [3 9];                    % thermocouple nodes (1-based): x = 0.02 m, 0.08 m
p.sig_y = 1.5; p.sig_w = 0.2;          % measurement / process noise [K]
p.q_l = 0.6^2; p.q_f = 1.0^2;          % Kalman process-noise variances
p.kp = 300; p.ti = 600;                % PI on chamber temperature
end

function o = opt(strategy, ramp_h, ramp_c)
o.strategy = strategy; o.ramp_h = NaN; o.ramp_c = NaN;
if nargin >= 3, o.ramp_h = ramp_h; o.ramp_c = ramp_c; end
o.dk = 0; o.dh = 0; o.dcp = 0; o.seed = 1; o.noise = true; o.use_kf = true; o.phi_g = NaN;
end

function [z, s] = lcg_u(s)             % 32-bit LCG (Numerical Recipes constants)
s = mod(1664525*s + 1013904223, 4294967296);
z = (s + 0.5)/4294967296;
end

function [z, s] = lcg_n(s)             % standard normal by Box-Muller
[u1, s] = lcg_u(s); [u2, s] = lcg_u(s);
z = sqrt(-2*log(u1))*cos(2*pi*u2);
end

function [A, B] = build_AB(p, kif, hi, ho, cf, he, cvol)
N = p.N; dx = p.L/(N-1); n = N + 1;
A = zeros(n, n); B = zeros(n, 1);
m = cvol*dx*ones(N, 1); m(1) = cvol*dx/2; m(N) = cvol*dx/2;
for i = 1:N-1
    g = kif(i)/dx;
    A(i, i)     = A(i, i)     - g/m(i);     A(i, i+1)   = A(i, i+1)   + g/m(i);
    A(i+1, i+1) = A(i+1, i+1) - g/m(i+1);   A(i+1, i)   = A(i+1, i)   + g/m(i+1);
end
A(1, 1)     = A(1, 1)     - hi/m(1);   A(1, N+1)   = A(1, N+1)   + hi/m(1);
A(N, N)     = A(N, N)     - ho/m(N);
A(N+1, N+1) = A(N+1, N+1) - (hi + he)/cf;   A(N+1, 1) = A(N+1, 1) + hi/cf;
B(N+1) = 1/cf;
end

function [Ad, Bd] = discretise(A, B, dt)
n = size(A, 1);
M = zeros(n+1, n+1); M(1:n, 1:n) = A*dt; M(1:n, n+1) = B*dt;
Ex = expm(M);
Ad = Ex(1:n, 1:n); Bd = Ex(1:n, n+1);
end

function S = stress_matrix(p)
% Free-plate thermal stress: sigma = -beta*(I - Pi)*theta, Pi = projection on {1, x}
N = p.N; L = p.L; dx = L/(N-1);
xs = linspace(0, L, N)';
w = dx*ones(N, 1); w(1) = dx/2; w(N) = dx/2;
W = diag(w);
V = [ones(N, 1), xs - L/2];
Pi = V*((V'*W*V)\(V'*W));
beta = p.E*p.aT/(1 - p.nu);
S = -beta*(eye(N) - Pi);
S = [S, zeros(N, 1)];
end

function [mdl, Cc, Hm] = model_set(p)
N = p.N; n = N + 1; cvol = p.rho*p.cp;
S = stress_matrix(p);
Cc = [S/p.St; -S/p.Sc];                          % utilisation rows (tension; compression)
Hm = zeros(numel(p.sens_idx) + 1, n);
for r = 1:numel(p.sens_idx), Hm(r, p.sens_idx(r)) = 1; end
Hm(end, N+1) = 1;
R = p.sig_y^2*eye(size(Hm, 1));
Q = diag([p.q_l*ones(1, N), p.q_f]);
modes = {'heat', 'cool'}; hes = [p.he_heat, p.he_cool];
for q = 1:2
    kif = p.k_model*ones(N-1, 1);
    [A, B] = build_AB(p, kif, p.hi, p.ho, p.cf, hes(q), cvol);
    [Ad, Bd] = discretise(A, B, p.dt);
    Pc = 10*eye(n);
    for it = 1:4000                              % steady-state Riccati iteration
        Pm = Ad*Pc*Ad' + Q;
        K  = (Pm*Hm')/(Hm*Pm*Hm' + R);
        Pn = (eye(n) - K*Hm)*Pm;
        if max(abs(Pn(:) - Pc(:))) < 1e-10, Pc = Pn; break; end
        Pc = Pn;
    end
    Pm = Ad*Pc*Ad' + Q;
    K  = (Pm*Hm')/(Hm*Pm*Hm' + R);
    Mall = zeros(p.H*2*N, n); Gall = zeros(p.H*2*N, 1);
    Aj = eye(n); Gam = zeros(n, 1);
    for j = 1:p.H
        Gam = Ad*Gam + Bd;                       % sum_{i<j} Ad^i * Bd
        Aj  = Ad*Aj;
        rows = (j-1)*2*N + (1:2*N);
        Mall(rows, :) = Cc*Aj; Gall(rows) = Cc*Gam;
    end
    mdl.(modes{q}).Ad = Ad; mdl.(modes{q}).Bd = Bd; mdl.(modes{q}).K = K;
    mdl.(modes{q}).Mall = Mall; mdl.(modes{q}).Gall = Gall;
end
end

function th_new = plant_step(p, th, u, he, dk, dh, dcp, w)
N = p.N; cvol = p.rho*p.cp*(1 + dcp);
T = th(1:N) + p.Ta;
Tif = 0.5*(T(1:end-1) + T(2:end));
kif = p.k_true0*(1 - p.k_slope*(Tif - 25))*(1 + dk);
[A, B] = build_AB(p, kif, p.hi*(1 + dh), p.ho*(1 + 0.5*dh), p.cf, he, cvol);
[Ad, Bd] = discretise(A, B, p.dt);
th_new = Ad*th + Bd*u + w;
end

function out = run_cycle(p, mdl, Cc, Hm, o)
N = p.N; n = N + 1; dt = p.dt;
s = mod(o.seed, 4294967296);
th = zeros(n, 1); xh = zeros(n, 1); xh_pred = zeros(n, 1);
phase = 'heat'; t_soak0 = NaN; t_cool0 = NaN;
integ = 0; nsteps = floor(p.tmax/dt);
rt = zeros(nsteps, 1); rTf = rt; rT1 = rt; rTN = rt; ru = rt; rphi = rt; rphih = rt;
energy = 0; infeas = 0; phi_heat = 0; phi_cool = 0; t = 0; kk = 0;
pg = o.phi_g; if isnan(pg), pg = p.phi_g; end
for k = 1:nsteps
    if strcmp(phase, 'cool'), md = 'cool'; he = p.he_cool; else, md = 'heat'; he = p.he_heat; end
    mm = mdl.(md);
    % ---- measurement and estimate update
    yv = Hm*th;
    if o.noise
        for r = 1:size(Hm, 1), [z, s] = lcg_n(s); yv(r) = yv(r) + p.sig_y*z; end
    end
    if o.use_kf, xh = xh_pred + mm.K*(yv - Hm*xh_pred); else, xh = xh_pred; end
    Tf_meas = yv(end) + p.Ta;
    % ---- phase logic
    if strcmp(phase, 'heat') && Tf_meas >= p.Tset - 3, phase = 'soak'; t_soak0 = t; end
    if strcmp(phase, 'soak') && (t - t_soak0) >= p.t_soak
        phase = 'cool'; t_cool0 = t; mm = mdl.cool; he = p.he_cool;
    end
    % ---- reference
    if strcmp(o.strategy, 'ramp')
        if strcmp(phase, 'heat'),     Tref = p.Ta + o.ramp_h*t/3600;
        elseif strcmp(phase, 'soak'), Tref = p.Tset;
        else,                         Tref = max(p.Tset - o.ramp_c*(t - t_cool0)/3600, p.Tlow);
        end
    else
        if ~strcmp(phase, 'cool'), Tref = p.Tset; else, Tref = p.Tlow; end
    end
    % ---- nominal PI
    e = Tref - Tf_meas;
    u_nom = p.kp*e + p.kp/p.ti*integ;
    u_cmd = min(max(u_nom, 0), p.umax);
    % ---- predictive stress safety filter
    if strcmp(o.strategy, 'sapg')
        a = mm.Mall*xh; b = mm.Gall; rhs = pg - a;
        pos = b > 1e-12; neg = b < -1e-12;
        hi_ = p.umax; if any(pos), hi_ = min(hi_, min(rhs(pos)./b(pos))); end
        lo_ = 0;      if any(neg), lo_ = max(lo_, max(rhs(neg)./b(neg))); end
        hi_ = max(hi_, 0);
        if lo_ > hi_, infeas = infeas + 1; u_f = 0.5*(lo_ + hi_);
        else,         u_f = min(max(u_cmd, lo_), hi_);
        end
        u = min(max(u_f, 0), p.umax);
    else
        u = u_cmd;
    end
    if abs(u - u_nom) < 1e-9, integ = integ + e*dt; end     % clamping anti-windup
    % ---- record true quantities
    phi_true = max(Cc*th);
    kk = kk + 1;
    rt(kk) = t; rTf(kk) = th(N+1) + p.Ta; rT1(kk) = th(1) + p.Ta; rTN(kk) = th(N) + p.Ta;
    ru(kk) = u; rphi(kk) = phi_true; rphih(kk) = max(Cc*xh);
    if strcmp(phase, 'heat') || strcmp(phase, 'soak'), phi_heat = max(phi_heat, phi_true);
    else, phi_cool = max(phi_cool, phi_true); end
    energy = energy + u*dt;
    if strcmp(phase, 'cool') && (th(1) + p.Ta) <= p.Tend_hot, break; end
    % ---- propagate plant and estimator
    w = zeros(n, 1);
    if o.noise
        for i = 1:N, [z, s] = lcg_n(s); w(i) = p.sig_w*z; end
    end
    th = plant_step(p, th, u, he, o.dk, o.dh, o.dcp, w);
    xh_pred = mm.Ad*xh + mm.Bd*u;
    t = t + dt;
end
out.t = rt(1:kk); out.Tf = rTf(1:kk); out.T1 = rT1(1:kk); out.TN = rTN(1:kk);
out.u = ru(1:kk); out.phi = rphi(1:kk); out.phi_hat = rphih(1:kk);
out.t_total = t; out.t_soak0 = t_soak0; out.phi_heat = phi_heat; out.phi_cool = phi_cool;
out.energy_kwh = energy/3.6e6; out.infeas = infeas; out.finished = double(strcmp(phase, 'cool'));
end

function r = best_ramp(p, mdl, Cc, Hm, kind, phi_lim)
lo = 2; hi = 400;
for it = 1:18
    mid = 0.5*(lo + hi);
    if kind == 'h'
        o = opt('ramp', mid, 1e4); o.noise = false; v = run_cycle(p, mdl, Cc, Hm, o).phi_heat;
    else
        o = opt('ramp', 1e4, mid); o.noise = false; v = run_cycle(p, mdl, Cc, Hm, o).phi_cool;
    end
    if v <= phi_lim, lo = mid; else, hi = mid; end
end
r = lo;
end

function m = mc_mean(p, mdl, Cc, Hm, o, draws, NS)
v = zeros(NS, 3);
for i = 1:NS
    o.dk = draws(i,1); o.dh = draws(i,2); o.dcp = draws(i,3); o.seed = 1000 + i; o.noise = true;
    r = run_cycle(p, mdl, Cc, Hm, o);
    v(i, :) = [r.t_total/3600, max(r.phi_heat, r.phi_cool), r.phi_heat^p.m_dmg + r.phi_cool^p.m_dmg];
end
m = mean(v, 1);
end
